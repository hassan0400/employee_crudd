import os

class Config:
    SECRET_KEY = 'secretkey'  # Change this to a strong secret in production
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')

    # MySQL Configuration
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'employee_db'
