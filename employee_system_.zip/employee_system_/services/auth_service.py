from werkzeug.security import check_password_hash
from flask_login import login_user
from models.user_model import User
from extensions import mysql

class AuthService:
    def login(self, username, password):
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", [username])
        user = cur.fetchone()
        if user and check_password_hash(user[2], password):
            login_user(User(user[0], user[1]))
            return True
        return False
