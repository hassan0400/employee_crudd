from datetime import date, datetime
from extensions import mysql

class AttendanceService:
    def mark_attendance(self, emp_id):
        today = date.today()
        cur = mysql.connection.cursor()

        cur.execute("SELECT * FROM attendance WHERE employee_id=%s AND date=%s", (emp_id, today))
        record = cur.fetchone()
        now = datetime.now().time()

        cur.execute("SELECT name FROM employees WHERE id=%s", [emp_id])
        emp = cur.fetchone()
        emp_name = emp[0] if emp else 'Employee'

        if not record:
            cur.execute("INSERT INTO attendance (employee_id, date, sign_in) VALUES (%s, %s, %s)",
                        (emp_id, today, now))
            mysql.connection.commit()
            return f'{emp_name} - Sign In recorded'
        elif record[3] is None:
            cur.execute("UPDATE attendance SET sign_out=%s WHERE id=%s", (now, record[0]))
            mysql.connection.commit()
            return f'{emp_name} - Sign Out recorded'
        else:
            return f'{emp_name} - Already Signed Out'